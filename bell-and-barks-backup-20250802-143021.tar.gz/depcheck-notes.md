# Dependency Check Configuration

## Ignored Dependencies

### tailwindcss

- **Why ignored**: Used via CSS import (`@import "tailwindcss"`) and Vite plugin
- **Location**: `src/index.css` and `vite.config.js`
- **Reason**: Depcheck doesn't detect CSS imports and build-time plugin usage
- **Status**: Required for styling system

## Configuration Notes

- `skip-missing: true` - Skips missing dependency checks
- `ignoreDirs` - Excludes dist and node_modules from analysis
